XPlayerCards hero image assets

xpc-hero.webp
- The exact generated game-lineup artwork, optimized to WebP for the landing page.
- 1800 x 749 pixels.

xpc-social-preview.jpg
- The same artwork composed for 1200 x 630 social preview cards.
- Uses the full game-lineup image without cropping away the puzzle game areas.

These are prepared assets only. They have not yet been copied into or deployed from the Mac project because the Remote Desktop Commander device is currently offline.
