import http from "node:http";
import { randomBytes } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { normalizeCardConfig, cardSlugify, renderCardPage } from "./lib/cards.js";

// Workspace 3 — Marketing (Interactive Post Studio) ONLY.
// Fully isolated from the arcade/studio workspace (server.mjs, port 4178).
const root = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.join(root, "local-tools", "marketing");
const port = Number(process.env.MARKETING_PORT || 4179);
const types = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp"
};

const localViews = new Map([
  ["/", "index.html"],
  ["/index.html", "index.html"]
]);

let cardHtml = "";
let cardPoster = null;

const dataDir = path.join(appRoot, ".data");
const cardPreviewFile = path.join(dataDir, "card-preview.html");
const cardPosterFile = path.join(dataDir, "card-poster.png");
const subscribersFile = path.join(dataDir, "subscribers.json");
// Hosted-card mirror (file-backed stand-in for the Neon cards tables).
const cardsFile = path.join(dataDir, "cards.json");
const cardSubscribersFile = path.join(dataDir, "card-subscribers.json");

async function readCards() {
  try { return JSON.parse(await readFile(cardsFile, "utf8")); } catch { return []; }
}
async function writeCards(cards) {
  await writeFile(cardsFile, JSON.stringify(cards, null, 2));
}
async function readCardSubscribers() {
  try { return JSON.parse(await readFile(cardSubscribersFile, "utf8")); } catch { return []; }
}
async function writeCardSubscribers(rows) {
  await writeFile(cardSubscribersFile, JSON.stringify(rows, null, 2));
}
function cardBaseUrl() {
  return `http://localhost:${port}`;
}
async function forwardToWebhook(webhook, payload, timeoutMs = 5000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    return res.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

async function ensureDataDir() {
  await mkdir(dataDir, { recursive: true });
}

function readBody(req, limit = 2_000_000) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => {
      data += chunk;
      if (data.length > limit) {
        reject(new Error("Payload too large."));
        req.destroy();
      }
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

function isLocalOrigin(origin) {
  return !origin || [`http://localhost:${port}`, `http://127.0.0.1:${port}`].includes(origin);
}

async function readSubscribers() {
  try {
    return JSON.parse(await readFile(subscribersFile, "utf8"));
  } catch {
    return [];
  }
}

function sendJson(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  res.end(JSON.stringify(body));
}

const CARD_SLUG = "([a-z0-9][a-z0-9-]{3,59})";

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    const pathname = decodeURIComponent(url.pathname);

    if (pathname === "/__xpc/health") {
      sendJson(res, 200, { ok: true, workspace: "marketing", port });
      return;
    }

    if (pathname === "/__xpc/subscribe") {
      if (req.method !== "POST") {
        sendJson(res, 405, { error: "Method not allowed." });
        return;
      }
      if (!isLocalOrigin(req.headers.origin)) {
        sendJson(res, 403, { error: "Local origin required." });
        return;
      }
      let payload;
      try {
        payload = JSON.parse((await readBody(req)) || "{}");
      } catch {
        sendJson(res, 400, { error: "Invalid JSON." });
        return;
      }
      const email = String(payload.email || "").trim().toLowerCase();
      const list = String(payload.list || "test").trim().toLowerCase().slice(0, 60) || "test";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
        sendJson(res, 400, { error: "Enter a valid email address." });
        return;
      }
      await ensureDataDir();
      const subscribers = await readSubscribers();
      const existing = subscribers.find(entry => entry.email === email && entry.list === list);
      if (existing) {
        sendJson(res, 200, { ok: true, already: true, count: subscribers.length, message: "Already subscribed." });
        return;
      }
      subscribers.push({ email, list, at: new Date().toISOString() });
      await writeFile(subscribersFile, JSON.stringify(subscribers, null, 2));
      sendJson(res, 200, { ok: true, already: false, count: subscribers.length, message: "Subscribed." });
      return;
    }

    if (pathname === "/__xpc/subscribers") {
      if (req.method !== "GET") {
        sendJson(res, 405, { error: "Method not allowed." });
        return;
      }
      sendJson(res, 200, { count: (await readSubscribers()).length, subscribers: await readSubscribers() });
      return;
    }

    if (pathname === "/__xpc/card") {
      if (req.method !== "POST") {
        sendJson(res, 405, { error: "Method not allowed." });
        return;
      }
      if (!isLocalOrigin(req.headers.origin)) {
        sendJson(res, 403, { error: "Local origin required." });
        return;
      }
      let payload;
      try {
        payload = JSON.parse((await readBody(req)) || "{}");
      } catch {
        sendJson(res, 400, { error: "Invalid JSON." });
        return;
      }
      if (typeof payload.html !== "string" || !payload.html.includes("<html")) {
        sendJson(res, 400, { error: "Card HTML missing." });
        return;
      }
      await ensureDataDir();
      cardHtml = payload.html;
      await writeFile(cardPreviewFile, cardHtml);
      if (typeof payload.posterDataUrl === "string" && payload.posterDataUrl.startsWith("data:image/png;base64,")) {
        cardPoster = Buffer.from(payload.posterDataUrl.slice("data:image/png;base64,".length), "base64");
        await writeFile(cardPosterFile, cardPoster);
      }
      sendJson(res, 200, { ok: true, url: `/__xpc/card/preview` });
      return;
    }

    if (pathname === "/__xpc/card/preview") {
      if (req.method !== "GET") {
        sendJson(res, 405, { error: "Method not allowed." });
        return;
      }
      if (!cardHtml) {
        try { cardHtml = await readFile(cardPreviewFile, "utf8"); } catch {}
      }
      if (!cardHtml) {
        res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
        res.end("<!doctype html><meta charset=\"utf-8\"><title>No card yet</title><body style=\"background:#0d0f12;color:#eee;font:15px system-ui;display:grid;place-items:center;height:100vh;margin:0\"><div style=\"text-align:center\"><p style=\"font-size:40px;margin:0\">✳</p><p>Open the Marketing workspace, design a card, then press <b>Open live card ↗</b>.</p></div>");
        return;
      }
      res.writeHead(200, {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "frame-ancestors 'self' https://twitter.com https://x.com https://*.twitter.com https://*.x.com"
      });
      res.end(cardHtml);
      return;
    }

    if (pathname === "/__xpc/card/preview/poster.png") {
      if (!cardPoster) {
        try { cardPoster = await readFile(cardPosterFile); } catch {}
      }
      if (!cardPoster) {
        res.writeHead(404);
        res.end("Not found");
        return;
      }
      res.writeHead(200, {
        "Content-Type": "image/png",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff"
      });
      res.end(cardPoster);
      return;
    }

    // ---- Hosted cards (local mirror of the production /c + /api/cards routes) ----
    const cardsListMatch = pathname === "/api/cards";
    const cardSubMatch = pathname.match(new RegExp(`^/api/cards/${CARD_SLUG}/subscribe/?$`));
    const cardPosterMatch = pathname.match(new RegExp(`^/api/cards/${CARD_SLUG}/poster/?$`));
    const cardSubsMatch = pathname.match(new RegExp(`^/api/cards/${CARD_SLUG}/subscribers/?$`));
    const cardMatch = pathname.match(new RegExp(`^/api/cards/${CARD_SLUG}/?$`));
    const cardPageMatch = pathname.match(new RegExp(`^/c/${CARD_SLUG}/?$`));

    if (cardsListMatch && req.method === "GET") {
      const cards = await readCards();
      const subs = await readCardSubscribers();
      sendJson(res, 200, {
        cards: cards.map(card => ({
          slug: card.slug,
          kind: card.kind,
          config: card.config,
          createdAt: card.createdAt,
          updatedAt: card.updatedAt,
          subscriberCount: subs.filter(row => row.cardSlug === card.slug).length,
          url: `${cardBaseUrl()}/c/${card.slug}`,
          posterUrl: `${cardBaseUrl()}/api/cards/${card.slug}/poster`
        }))
      });
      return;
    }

    if (cardsListMatch && req.method === "POST") {
      if (!isLocalOrigin(req.headers.origin)) {
        sendJson(res, 403, { error: "Local origin required." });
        return;
      }
      let payload;
      try {
        payload = JSON.parse((await readBody(req)) || "{}");
      } catch {
        sendJson(res, 400, { error: "Invalid JSON." });
        return;
      }
      const config = normalizeCardConfig(payload.config || {});
      let poster = String(payload.posterBase64 || "").replace(/^data:image\/png;base64,/i, "");
      if (!poster || poster.length > 1_200_000) {
        sendJson(res, 413, { error: "Poster is missing or too large. Use a 640×480 PNG under about 900 KB." });
        return;
      }
      const png = Buffer.from(poster, "base64");
      if (png.length < 24 || png.subarray(0, 8).toString("hex") !== "89504e470d0a1a0a") {
        sendJson(res, 400, { error: "Poster must be a valid PNG image." });
        return;
      }
      await ensureDataDir();
      const cards = await readCards();
      const slug = `${cardSlugify(config.brand)}-${randomBytes(3).toString("hex")}`;
      const now = new Date().toISOString();
      cards.unshift({ slug, kind: "newsletter", config, posterBase64: png.toString("base64"), createdAt: now, updatedAt: now });
      await writeCards(cards);
      sendJson(res, 201, {
        slug, config,
        url: `${cardBaseUrl()}/c/${slug}`,
        posterUrl: `${cardBaseUrl()}/api/cards/${slug}/poster`,
        createdAt: now
      });
      return;
    }

    if (cardSubMatch && req.method === "POST") {
      const slug = cardSubMatch[1];
      if (!isLocalOrigin(req.headers.origin)) {
        sendJson(res, 403, { error: "Local origin required." });
        return;
      }
      let payload;
      try {
        payload = JSON.parse((await readBody(req)) || "{}");
      } catch {
        sendJson(res, 400, { error: "Invalid JSON." });
        return;
      }
      const email = String(payload.email || "").trim().toLowerCase();
      const list = String(payload.list || "newsletter").trim().slice(0, 60) || "newsletter";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
        sendJson(res, 400, { error: "Please enter a valid email address." });
        return;
      }
      await ensureDataDir();
      const cards = await readCards();
      const card = cards.find(entry => entry.slug === slug);
      if (!card) {
        sendJson(res, 404, { error: "Card not found." });
        return;
      }
      const rows = await readCardSubscribers();
      const already = rows.some(row => row.cardSlug === slug && row.email === email && row.list === list);
      if (!already) rows.push({ cardSlug: slug, email, list, at: new Date().toISOString() });
      await writeCardSubscribers(rows);
      let forwarded = false;
      if (card.config.webhook) forwarded = await forwardToWebhook(card.config.webhook, { email, list, card: slug, source: "wotagame-card" });
      sendJson(res, 200, { ok: true, already, forwarded, count: rows.filter(row => row.cardSlug === slug).length });
      return;
    }

    if (cardSubsMatch && req.method === "GET") {
      const rows = await readCardSubscribers();
      const forCard = rows.filter(row => row.cardSlug === cardSubsMatch[1]);
      sendJson(res, 200, { count: forCard.length, subscribers: forCard });
      return;
    }

    if (cardPosterMatch && (req.method === "GET" || req.method === "HEAD")) {
      const cards = await readCards();
      const card = cards.find(entry => entry.slug === cardPosterMatch[1]);
      if (!card?.posterBase64) {
        sendJson(res, 404, { error: "Poster not found." });
        return;
      }
      const png = Buffer.from(card.posterBase64, "base64");
      res.writeHead(200, {
        "Content-Type": "image/png",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
        "Content-Length": String(png.length)
      });
      res.end(req.method === "HEAD" ? undefined : png);
      return;
    }

    if (cardMatch && (req.method === "GET" || req.method === "PUT")) {
      const slug = cardMatch[1];
      const cards = await readCards();
      const card = cards.find(entry => entry.slug === slug);
      if (req.method === "GET") {
        if (!card) {
          sendJson(res, 404, { error: "Card not found." });
          return;
        }
        const subs = await readCardSubscribers();
        sendJson(res, 200, {
          slug: card.slug, kind: card.kind, config: card.config,
          createdAt: card.createdAt, updatedAt: card.updatedAt,
          subscriberCount: subs.filter(row => row.cardSlug === slug).length,
          url: `${cardBaseUrl()}/c/${slug}`,
          posterUrl: `${cardBaseUrl()}/api/cards/${slug}/poster`
        });
        return;
      }
      if (!isLocalOrigin(req.headers.origin)) {
        sendJson(res, 403, { error: "Local origin required." });
        return;
      }
      if (!card) {
        sendJson(res, 404, { error: "Card not found." });
        return;
      }
      let payload;
      try {
        payload = JSON.parse((await readBody(req)) || "{}");
      } catch {
        sendJson(res, 400, { error: "Invalid JSON." });
        return;
      }
      const config = normalizeCardConfig(payload.config || {});
      let poster = String(payload.posterBase64 || "").replace(/^data:image\/png;base64,/i, "");
      if (!poster || poster.length > 1_200_000) {
        sendJson(res, 413, { error: "Poster is missing or too large. Use a 640×480 PNG under about 900 KB." });
        return;
      }
      const png = Buffer.from(poster, "base64");
      if (png.length < 24 || png.subarray(0, 8).toString("hex") !== "89504e470d0a1a0a") {
        sendJson(res, 400, { error: "Poster must be a valid PNG image." });
        return;
      }
      card.config = config;
      card.posterBase64 = png.toString("base64");
      card.updatedAt = new Date().toISOString();
      await writeCards(cards);
      sendJson(res, 200, {
        slug: card.slug, config,
        url: `${cardBaseUrl()}/c/${slug}`,
        posterUrl: `${cardBaseUrl()}/api/cards/${slug}/poster`,
        updatedAt: card.updatedAt
      });
      return;
    }

    if (cardPageMatch && (req.method === "GET" || req.method === "HEAD")) {
      const slug = cardPageMatch[1];
      const cards = await readCards();
      const card = cards.find(entry => entry.slug === slug);
      if (!card) {
        res.writeHead(404, {
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "no-store"
        });
        res.end("<!doctype html><title>Card not found</title><main><h1>Card not found</h1><p>This interactive card may have been unpublished.</p></main>");
        return;
      }
      const html = renderCardPage({ slug, config: card.config, baseUrl: cardBaseUrl() });
      res.writeHead(200, {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Content-Security-Policy": "frame-ancestors 'self' https://twitter.com https://x.com https://*.twitter.com https://*.x.com"
      });
      res.end(html);
      return;
    }

    const rel = localViews.get(pathname) || pathname.replace(/^\/+/, "");
    const file = path.resolve(appRoot, rel);
    if (!file.startsWith(appRoot + path.sep)) {
      res.writeHead(403);
      res.end("Forbidden");
      return;
    }
    const body = await readFile(file);
    res.writeHead(200, {
      "Content-Type": types[path.extname(file)] || "application/octet-stream",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff"
    });
    res.end(body);
  } catch {
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Not found");
  }
}).listen(port, "127.0.0.1", () => console.log(`WotaGame marketing workspace running at http://localhost:${port}`));
