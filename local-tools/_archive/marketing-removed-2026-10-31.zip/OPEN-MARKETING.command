#!/bin/zsh
cd /Users/ravinderpoonia/Developer/WotaGame
if ! lsof -nP -iTCP:4179 -sTCP:LISTEN >/dev/null 2>&1; then
  nohup node server-marketing.mjs > /tmp/wotagame-marketing.log 2>&1 &
  sleep 1
fi
open -na "Google Chrome" --args --new-window "http://localhost:4179/"
