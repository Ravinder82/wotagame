# Interactive Post Studio (Marketing workspace)

- File: `local-tools/marketing/index.html` — rewritten 2026-10-23 as the "Interactive Post Studio".
- Local URL: `http://localhost:4179/` (isolated marketing server since 2026-10-27).
- Local/internal utility; `.vercelignore` excludes `local-tools/` from production.
- Owner directive (2026-10-23): Studio = game generation/publish/ZIP only; Marketing = the interactive-post SaaS direction (newsletter signup inside the X timeline via the `twitter:player` card mechanic, proven live by Tibo's @tibo_maker newsletter card). This is the seed of a real SaaS product — testable locally first.

## Categories (rail at top)

1. **Newsletter (Live)** — full widget builder: card name, handle, social-proof badge, headline (`*stars*` wraps to accent), sub-headline, email destination (local file / webhook), accent color, button label, footer line, success message, Card URL. Live simulator: Desktop timeline view (avatar/post/player box/repost+like) and Mobile 70/30 mode (card in top 70%, tweet drawer pinned below — mirrors X mobile chrome). Tweet-copy generator with three hooks (Curiosity / Value-first / Short punch), character counter, Copy tweet, Open X composer, Download poster.png (640×480 canvas).
2. **Game promo (Live)** — the previous Marketing tool, unchanged in capability: 4 games (only Word Finder live; never invent URLs for Coming Soon), X link-card mockup, 280-char counter, Instagram story/reel/bio copy, canvas share assets at 1200×630, 1080×1080, 1080×1920, Studio draft import (`xminigame.draft`).
3. **Interactive quiz (Soon)** — visible stub with roadmap copy; same player-card engine planned.

## Card engine and local server endpoints

- Generated card is a standalone HTML page with `twitter:card=player` meta (640×480), no `<form>` (X iframe sandbox blocks forms — uses `fetch()`), interactive elements kept in the top 70% (mobile tweet drawer covers bottom 30%).
- `server.mjs` (additive routes, local only): `POST /__xpc/subscribe` (origin-checked, validates email, dedupes per list, appends to `local-tools/.data/subscribers.json`), `GET /__xpc/subscribers`, `POST /__xpc/card` (stores latest generated card + poster on disk), `GET /__xpc/card/preview` (serves it with `Content-Security-Policy: frame-ancestors 'self' https://twitter.com https://x.com https://*.twitter.com https://*.x.com`), `GET /__xpc/card/preview/poster.png`.
- "Open live card" POSTs the current card then opens `/__xpc/card/preview` in a real tab. "Export card ZIP" downloads standalone `index.html` + `poster.png` + `vercel.json` (with the frame-ancestors CSP header) for deploying at a stable no-redirect URL.

## Rules and storage

- Drafts stay in this browser: `xplayercards.marketing.draft` (now includes `category` and the whole `nl` newsletter config alongside the original game-promo fields). It can import handle/copy from the Studio draft (`xminigame.draft`).
- It does not auto-publish and never auto-posts. The owner reviews and posts manually.
- Email destination defaults to local-file storage (this Mac only); webhook mode accepts Beehiiv/Substack/ConvertKit/Make endpoints — switch before going live.
- For unfinished games, do not invent a game URL; use the homepage or state Coming Soon.
- Keep Post Studio distinct from Game Studio. Do not delete existing publishing, ZIP export, or game-promo features.
- Production requests to `/local-tools/*` return 404 (verified 2026-10-22; still excluded).
- Browser verification 2026-10-23: zero console errors; subscribe flow end-to-end (browser → server → file) proven; mobile 70/30 toggle, category switching, and tweet-copy generator all verified in browser and via headless screenshots.
- **Workspace change 2026-10-27:** Post Studio moved to its own isolated server: `http://localhost:4179` (`node server-marketing.mjs`, app at `local-tools/marketing/index.html`, data in `local-tools/marketing/.data/`). Port 4178 no longer serves `/marketing` or any `/api/cards*`/`/c/*`/`/__xpc/card*`/`/__xpc/subscribe*` routes. The old "Sync studio draft" button was removed: localhost:4178 and localhost:4179 are different origins, so `xminigame.draft` localStorage is no longer readable cross-tool. Cross-links are plain `window.open` URLs (Studio → `http://localhost:4179/`, Post Studio → `http://localhost:4178/studio`). Old drafts from the 4178 origin do not carry over.

## Phase 2: hosted card publish (local-first)

- Added a Newsletter Publish panel to the design pane: platform target select (Local / Live `https://wotagame.vercel.app`), token field (≥32 chars, session-only, never persisted in localStorage), Publish new card / Update published card buttons, subscriber count display, "Open hosted card ↗" opens the real `/c/` URL.
- Publish → POST/PUT `{config,posterBase64}` to `/api/cards` (local) or `https://wotagame.vercel.app/api/cards` (live, bearer token required). On success stores `nl.slug` + `nl.url=base+/c/:slug`, switches mode to hosted, refreshes subscriber count.
- Hosted mode: preview loads the real hosted `/c/:slug` card in the iframe (the exact URL X loads as the player). Local mode keeps testing on `/__xpc/card/preview`.
- ZIP export retained as a hedge per owner directive; one-click "Open X composer" posting retained as-is. No auto-post; subscriber list stays per card; webhook forward (Beehiiv/Make/n8n) optional and best-effort.
- No production deploy or Neon schema run without explicit owner approval. Local `DATABASE_URL` is placeholder-only.
